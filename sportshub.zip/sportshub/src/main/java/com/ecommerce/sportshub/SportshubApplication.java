package com.ecommerce.sportshub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportshubApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportshubApplication.class, args);
	}

}
