package com.ecommerce.sportshub.entity;

public class Product {
}
