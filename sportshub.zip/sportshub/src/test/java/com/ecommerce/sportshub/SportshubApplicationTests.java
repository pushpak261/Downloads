package com.ecommerce.sportshub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportshubApplicationTests {

	@Test
	void contextLoads() {
	}

}
